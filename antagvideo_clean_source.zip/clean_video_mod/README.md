# Antag Video Mod (Clean Version)

Fullscreen video player for Minecraft 26.2 (Fabric)

## Commands
- `/videoplay` → shows list of videos + help
- `/videoplay Intro <player>` → plays the video
- `/videostop` → stops the video
- ESC → skip

## Build
1. Install JDK 21
2. Run: `./gradlew build`
3. Jar appears in `build/libs/`

## Notes
- Contains 402 frames (~ first full pass of the video at ~9.5 FPS)
- Audio is included
- Uses NativeImage so it should work on both PC and Android
