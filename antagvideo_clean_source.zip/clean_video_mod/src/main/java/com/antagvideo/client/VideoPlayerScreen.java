package com.antagvideo.client;

import com.antagvideo.AntagVideoMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class VideoPlayerScreen extends Screen {
    private static final Identifier SOUND_ID = Identifier.of(AntagVideoMod.MOD_ID, "intro");

    private final String videoName;
    private final String playerName;
    private long startTimeMs;
    private boolean soundStarted = false;
    private final VideoRenderer renderer = new VideoRenderer();

    public VideoPlayerScreen(String videoName, String playerName) {
        super(Text.literal(videoName));
        this.videoName = videoName;
        this.playerName = playerName;
    }

    @Override
    protected void init() {
        super.init();
        this.startTimeMs = System.currentTimeMillis();
        if (!soundStarted) {
            try {
                MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvent.of(SOUND_ID), 1.0f, 1.0f)
                );
            } catch (Exception e) {
                AntagVideoMod.LOGGER.warn("Could not play sound: {}", e.getMessage());
            }
            soundStarted = true;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        double timeSec = (System.currentTimeMillis() - startTimeMs) / 1000.0;
        renderer.render(context, this.width, this.height, timeSec, videoName, playerName);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void tick() {
        super.tick();
        // Auto close after video length
        if (System.currentTimeMillis() - startTimeMs > 44000) {
            this.close();
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        try {
            MinecraftClient.getInstance().getSoundManager().stopSounds(SOUND_ID, null);
        } catch (Exception ignored) {}
        super.close();
    }
}
