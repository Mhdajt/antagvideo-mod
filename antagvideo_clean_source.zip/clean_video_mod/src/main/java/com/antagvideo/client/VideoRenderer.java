package com.antagvideo.client;

import com.antagvideo.AntagVideoMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class VideoRenderer {
    // How many frames we actually shipped
    public static final int TOTAL_FRAMES = 402;
    public static final double FPS = 9.5;          // ~402 frames / 42.8s
    public static final double DURATION = 42.84;

    private final Map<Integer, Identifier> cache = new HashMap<>();

    public void render(DrawContext context, int sw, int sh, double timeSec,
                       String videoName, String playerName) {

        int frame = (int) (timeSec * FPS) + 1;
        if (frame < 1) frame = 1;
        if (frame > TOTAL_FRAMES) frame = TOTAL_FRAMES;

        Identifier tex = getFrame(frame);

        // Full black background first
        context.fill(0, 0, sw, sh, 0xFF000000);

        if (tex != null) {
            // Draw the frame stretched to fullscreen
            context.drawTexture(tex, 0, 0, 0, 0, sw, sh, sw, sh);
        } else {
            context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
                Text.literal("§cFrame " + frame + " failed to load"), 20, sh / 2, 0xFF5555);
        }

        // Progress bar
        int barH = 4;
        int prog = (int) Math.min(sw, (timeSec / DURATION) * sw);
        context.fill(0, sh - barH, prog, sh, 0xFF00E676);
        context.fill(prog, sh - barH, sw, sh, 0xFF222222);

        // HUD
        var tr = MinecraftClient.getInstance().textRenderer;
        context.drawTextWithShadow(tr,
            Text.literal("§e" + videoName + " §7→ §b" + playerName + "  §8| §f" + String.format("%.1fs", timeSec)),
            8, 8, 0xFFFFFF);
        context.drawTextWithShadow(tr,
            Text.literal("§8Frame " + frame + "/" + TOTAL_FRAMES + "   §7[ESC to skip]"),
            8, 22, 0xAAAAAA);
    }

    private Identifier getFrame(int index) {
        if (cache.containsKey(index)) return cache.get(index);

        String path = String.format("textures/frames/%04d.jpg", index);
        Identifier id = Identifier.of(AntagVideoMod.MOD_ID, path);

        try {
            MinecraftClient client = MinecraftClient.getInstance();
            Optional<Resource> res = client.getResourceManager().getResource(id);

            if (res.isPresent()) {
                try (InputStream in = res.get().getInputStream()) {
                    NativeImage img = NativeImage.read(in);
                    NativeImageBackedTexture dyn = new NativeImageBackedTexture(img);
                    Identifier dynId = Identifier.of(AntagVideoMod.MOD_ID, "dyn_frame_" + index);
                    client.getTextureManager().registerTexture(dynId, dyn);
                    cache.put(index, dynId);
                    return dynId;
                }
            } else {
                AntagVideoMod.LOGGER.warn("Missing frame resource: {}", path);
            }
        } catch (Exception e) {
            AntagVideoMod.LOGGER.error("Failed loading frame {}: {}", index, e.getMessage());
        }

        // last resort
        cache.put(index, id);
        return id;
    }
}
