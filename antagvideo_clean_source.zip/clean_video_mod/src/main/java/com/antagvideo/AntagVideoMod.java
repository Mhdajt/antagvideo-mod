package com.antagvideo;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AntagVideoMod implements ModInitializer {
    public static final String MOD_ID = "antagvideo";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Antag Video mod loaded - use /videoplay");
    }
}
