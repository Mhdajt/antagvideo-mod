package com.antagvideo.command;

import com.antagvideo.client.VideoPlayerScreen;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class VideoCommand {

    public static final String[] VIDEOS = { "Intro" };

    private static final SuggestionProvider<FabricClientCommandSource> VIDEO_SUGGESTIONS =
        (context, builder) -> CommandSource.suggestMatching(VIDEOS, builder);

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher,
                                net.minecraft.command.CommandRegistryAccess registryAccess) {

        dispatcher.register(literal("videoplay")
            .executes(ctx -> {
                ctx.getSource().sendFeedback(Text.literal("§6§l=== Antag Video ==="));
                ctx.getSource().sendFeedback(Text.literal("§eUsage: §f/videoplay <video> <player>"));
                ctx.getSource().sendFeedback(Text.literal("§eExample: §a/videoplay Intro Steve"));
                ctx.getSource().sendFeedback(Text.literal("§7Available videos:"));
                for (String v : VIDEOS) {
                    ctx.getSource().sendFeedback(Text.literal("  §b▶ " + v));
                }
                ctx.getSource().sendFeedback(Text.literal("§8Type §7/videostop §8to stop"));
                return 1;
            })
            .then(argument("video", StringArgumentType.word())
                .suggests(VIDEO_SUGGESTIONS)
                .then(argument("player", StringArgumentType.word())
                    .executes(ctx -> {
                        String video = StringArgumentType.getString(ctx, "video");
                        String player = StringArgumentType.getString(ctx, "player");

                        boolean found = false;
                        for (String v : VIDEOS) {
                            if (v.equalsIgnoreCase(video)) {
                                video = v;
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            ctx.getSource().sendFeedback(Text.literal("§cUnknown video §e" + video));
                            ctx.getSource().sendFeedback(Text.literal("§7Available: §bIntro"));
                            return 0;
                        }

                        String finalVideo = video;
                        MinecraftClient.getInstance().execute(() ->
                            MinecraftClient.getInstance().setScreen(new VideoPlayerScreen(finalVideo, player))
                        );

                        ctx.getSource().sendFeedback(Text.literal("§a▶ Playing §e" + video + " §afor §b" + player));
                        return 1;
                    })
                )
            )
        );

        dispatcher.register(literal("videostop")
            .executes(ctx -> {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.currentScreen instanceof VideoPlayerScreen) {
                    client.execute(() -> client.setScreen(null));
                    ctx.getSource().sendFeedback(Text.literal("§c⏹ Stopped"));
                } else {
                    ctx.getSource().sendFeedback(Text.literal("§7No video playing"));
                }
                return 1;
            })
        );
    }
}
